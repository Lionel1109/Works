CREATE DATABASE BackerShop;

GO

USE BackerShop;

CREATE TABLE Bread
(
	id INT PRIMARY KEY IDENTITY,
	name NVARCHAR(100) NOT NULL,
	dough NVARCHAR(100) NOT NULL,
	price NVARCHAR(100) NOT NULL,
);

CREATE TABLE Bun
(
	id INT PRIMARY KEY IDENTITY,
	name NVARCHAR(100) NOT NULL,
	dough NVARCHAR(100) NOT NULL,
	price NVARCHAR(100) NOT NULL,
);

CREATE TABLE Staff
(
	id INT PRIMARY KEY IDENTITY,
	name NVARCHAR(100) NOT NULL,
	surname NVARCHAR(100) NOT NULL,
	age INT NOT NULL,
);

CREATE TABLE Customer
(
	id INT PRIMARY KEY IDENTITY,
	name NVARCHAR(100) NOT NULL,
	email VARCHAR(200) NULL,
);

INSERT INTO Bread (name, dough, price)
	VALUES
	('Бородинский', 'дрожжевое', 40),
	('Пшеничный', 'дрожжевое', 23),
	('Ржаной хлеб', 'дрожжевое', 30),
	('Пшенично-ржаной', 'дрожжевое', 27);

INSERT INTO Bun (name, dough, price)
	VALUES 
	('Плюшки «Московские»', 'заварное', 40),
	('Плюшки «Московские»', 'заварное', 40),
	('Плюшки «Московские»', 'заварное', 40),
	('Плюшки «Московские»', 'заварное', 40);

INSERT INTO Staff (name, surname, age)
	VALUES
	('Дмитрий', 'Антонов', 24),
	('Анастасия', 'Полетаева', 28),
	('Егор', 'Лисков', 19),
	('Захар', 'Горин', 45);

INSERT INTO Customer (name)
	VALUES
	('Антон'),
	('Виталий'),
	('Яна'),
	('Михаил');