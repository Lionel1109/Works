CREATE DATABASE MainingRoom;
GO

USE MainingRoom;

CREATE TABLE Sofas
(
	id INT PRIMARY KEY IDENTITY,
	name NVARCHAR(100) NOT NULL,
	manufacturer NVARCHAR(100) NOT NULL,
	price INT NOT NULL,
	buy_date DATE DEFAULT CURRENT_TIMESTAMP,
);

CREATE TABLE Chairs
(
	id INT PRIMARY KEY IDENTITY,
	name NVARCHAR(100) NOT NULL,
	manufacturer NVARCHAR(100) NOT NULL,
	price INT NOT NULL,
	buy_date DATE DEFAULT CURRENT_TIMESTAMP,
);

CREATE TABLE Beds
(
	id INT PRIMARY KEY IDENTITY,
	name NVARCHAR(100) NOT NULL,
	manufacturer NVARCHAR(100) NOT NULL,
	price INT NOT NULL,
	buy_date DATE DEFAULT CURRENT_TIMESTAMP,
);

CREATE TABLE Wardrobes
(
	id INT PRIMARY KEY IDENTITY,
	name NVARCHAR(100) NOT NULL,
	manufacturer NVARCHAR(100) NOT NULL,
	price INT NOT NULL,
	buy_date DATE DEFAULT CURRENT_TIMESTAMP,
);

CREATE TABLE Lamps
(
	id INT PRIMARY KEY IDENTITY,
	name NVARCHAR(100) NOT NULL,
	manufacturer NVARCHAR(100) NOT NULL,
	price INT NOT NULL,
	buy_date DATE DEFAULT CURRENT_TIMESTAMP,
);

CREATE TABLE Desks
(
	id INT PRIMARY KEY IDENTITY,
	name NVARCHAR(100) NOT NULL,
	manufacturer NVARCHAR(100) NOT NULL,
	price INT NOT NULL,
	buy_date DATE DEFAULT CURRENT_TIMESTAMP,
);

CREATE TABLE Nightstand
(
	id INT PRIMARY KEY IDENTITY,
	name NVARCHAR(100) NOT NULL,
	manufacturer NVARCHAR(100) NOT NULL,
	price INT NOT NULL,
	buy_date DATE DEFAULT CURRENT_TIMESTAMP,
);

CREATE TABLE Windows
(
	id INT PRIMARY KEY IDENTITY,
	name NVARCHAR(100) NOT NULL,
	manufacturer NVARCHAR(100) NOT NULL,
	price INT NOT NULL,
	buy_date DATE DEFAULT CURRENT_TIMESTAMP,
);

CREATE TABLE Racks
(
	id INT PRIMARY KEY IDENTITY,
	name NVARCHAR(100) NOT NULL,
	manufacturer NVARCHAR(100) NOT NULL,
	price INT NOT NULL,
	buy_date DATE DEFAULT CURRENT_TIMESTAMP,
);

CREATE TABLE ShoeRacks
(
	id INT PRIMARY KEY IDENTITY,
	name NVARCHAR(100) NOT NULL,
	manufacturer NVARCHAR(100) NOT NULL,
	price INT NOT NULL,
	buy_date DATE DEFAULT CURRENT_TIMESTAMP,
);
INSERT INTO Sofas (name, manufacturer, price)
	VALUES
	('Антонио', 'ООО "Подстилкин"', 14000),
	('Антонио', 'ООО "Подстилкин"', 14000),
	('Антонио', 'ООО "Подстилкин"', 14000),
	('Антонио', 'ООО "Подстилкин"', 14000),
	('Антонио', 'ООО "Подстилкин"', 14000),
	('Антонио', 'ООО "Подстилкин"', 14000),
	('Антонио', 'ООО "Подстилкин"', 14000),
	('Антонио', 'ООО "Подстилкин"', 14000),
	('Антонио', 'ООО "Подстилкин"', 14000),
	('Антонио', 'ООО "Подстилкин"', 14000),
	('Михаил', 'ООО "Сколково"', 78000),
	('Михаил', 'ООО "Сколково"', 78000),
	('Михаил', 'ООО "Сколково"', 78000),
	('Михаил', 'ООО "Сколково"', 78000),
	('Михаил', 'ООО "Сколково"', 78000),
	('Михаил', 'ООО "Сколково"', 78000),
	('Михаил', 'ООО "Сколково"', 78000),
	('Михаил', 'ООО "Сколково"', 78000),
	('Михаил', 'ООО "Сколково"', 78000),
	('Михаил', 'ООО "Сколково"', 78000);

INSERT INTO Chairs (name, manufacturer, price)
	VALUES
	('Двухногий', 'Завод Петра Бездарного', 32000),
	('Двухногий', 'Завод Петра Бездарного', 32000),
	('Двухногий', 'Завод Петра Бездарного', 32000),
	('Двухногий', 'Завод Петра Бездарного', 32000),
	('Двухногий', 'Завод Петра Бездарного', 32000),
	('Двухногий', 'Завод Петра Бездарного', 32000),
	('Двухногий', 'Завод Петра Бездарного', 32000),
	('Двухногий', 'Завод Петра Бездарного', 32000),
	('Двухногий', 'Завод Петра Бездарного', 32000),
	('Двухногий', 'Завод Петра Бездарного', 32000),
	('Двухногий', 'Завод Петра Бездарного', 32000),
	('Двухногий', 'Завод Петра Бездарного', 32000),
	('Двухногий', 'Завод Петра Бездарного', 32000),
	('Двухногий', 'Завод Петра Бездарного', 32000),
	('Двухногий', 'Завод Петра Бездарного', 32000),
	('Двухногий', 'Завод Петра Бездарного', 32000),
	('Двухногий', 'Завод Петра Бездарного', 32000),
	('Двухногий', 'Завод Петра Бездарного', 32000),
	('Двухногий', 'Завод Петра Бездарного', 32000),
	('Двухногий', 'Завод Петра Бездарного', 32000);



INSERT INTO Beds (name, manufacturer, price)
	VALUES
	('Волга', 'Завод кроватей', 23000),
	('Волга', 'Завод кроватей', 23000),
	('Волга', 'Завод кроватей', 23000),
	('Волга', 'Завод кроватей', 23000),
	('Волга', 'Завод кроватей', 23000),
	('Волга', 'Завод кроватей', 23000),
	('Волга', 'Завод кроватей', 23000),
	('Волга', 'Завод кроватей', 23000),
	('Волга', 'Завод кроватей', 23000),
	('Волга', 'Завод кроватей', 23000),
	('Волга', 'Завод кроватей', 23000),
	('Волга', 'Завод кроватей', 23000),
	('Волга', 'Завод кроватей', 23000),
	('Волга', 'Завод кроватей', 23000),
	('Волга', 'Завод кроватей', 23000),
	('Волга', 'Завод кроватей', 23000),
	('Волга', 'Завод кроватей', 23000),
	('Волга', 'Завод кроватей', 23000),
	('Волга', 'Завод кроватей', 23000),
	('Волга', 'Завод кроватей', 23000);

INSERT INTO Wardrobes (name, manufacturer, price)
	VALUES
	('Помещала', 'Шкафник', 4900),
	('Помещала', 'Шкафник', 4900),
	('Помещала', 'Шкафник', 4900),
	('Помещала', 'Шкафник', 4900),
	('Помещала', 'Шкафник', 4900),
	('Помещала', 'Шкафник', 4900),
	('Помещала', 'Шкафник', 4900),
	('Помещала', 'Шкафник', 4900),
	('Помещала', 'Шкафник', 4900),
	('Помещала', 'Шкафник', 4900),
	('Помещала', 'Шкафник', 4900),
	('Помещала', 'Шкафник', 4900),
	('Помещала', 'Шкафник', 4900),
	('Помещала', 'Шкафник', 4900),
	('Помещала', 'Шкафник', 4900),
	('Помещала', 'Шкафник', 4900),
	('Помещала', 'Шкафник', 4900),
	('Помещала', 'Шкафник', 4900),
	('Помещала', 'Шкафник', 4900),
	('Помещала', 'Шкафник', 4900);


INSERT INTO Lamps (name, manufacturer, price)
	VALUES
	('Лэмп', 'Светильники Светы', 3400),
	('Лэмп', 'Светильники Светы', 3400),
	('Лэмп', 'Светильники Светы', 3400),
	('Лэмп', 'Светильники Светы', 3400),
	('Лэмп', 'Светильники Светы', 3400),
	('Лэмп', 'Светильники Светы', 3400),
	('Лэмп', 'Светильники Светы', 3400),
	('Лэмп', 'Светильники Светы', 3400),
	('Лэмп', 'Светильники Светы', 3400),
	('Лэмп', 'Светильники Светы', 3400),
	('Лэмп', 'Светильники Светы', 3400),
	('Лэмп', 'Светильники Светы', 3400),
	('Лэмп', 'Светильники Светы', 3400),
	('Лэмп', 'Светильники Светы', 3400),
	('Лэмп', 'Светильники Светы', 3400),
	('Лэмп', 'Светильники Светы', 3400),
	('Лэмп', 'Светильники Светы', 3400),
	('Лэмп', 'Светильники Светы', 3400),
	('Лэмп', 'Светильники Светы', 3400),
	('Лэмп', 'Светильники Светы', 3400);

INSERT INTO Desks (name, manufacturer, price)
	VALUES
	('Стол', 'Столичная пекарня', 79000),
	('Стол', 'Столичная пекарня', 79000),
	('Стол', 'Столичная пекарня', 79000),
	('Стол', 'Столичная пекарня', 79000),
	('Стол', 'Столичная пекарня', 79000),
	('Стол', 'Столичная пекарня', 79000),
	('Стол', 'Столичная пекарня', 79000),
	('Стол', 'Столичная пекарня', 79000),
	('Стол', 'Столичная пекарня', 79000),
	('Стол', 'Столичная пекарня', 79000),
	('Стол', 'Столичная пекарня', 79000),
	('Стол', 'Столичная пекарня', 79000),
	('Стол', 'Столичная пекарня', 79000),
	('Стол', 'Столичная пекарня', 79000),
	('Стол', 'Столичная пекарня', 79000),
	('Стол', 'Столичная пекарня', 79000),
	('Стол', 'Столичная пекарня', 79000),
	('Стол', 'Столичная пекарня', 79000),
	('Стол', 'Столичная пекарня', 79000),
	('Стол', 'Столичная пекарня', 79000);

INSERT INTO Nightstand (name, manufacturer, price)
	VALUES
	('Томбов', 'Завод тумбочек', 2300),
	('Томбов', 'Завод тумбочек', 2300),
	('Томбов', 'Завод тумбочек', 2300),
	('Томбов', 'Завод тумбочек', 2300),
	('Томбов', 'Завод тумбочек', 2300),
	('Томбов', 'Завод тумбочек', 2300),
	('Томбов', 'Завод тумбочек', 2300),
	('Томбов', 'Завод тумбочек', 2300),
	('Томбов', 'Завод тумбочек', 2300),
	('Томбов', 'Завод тумбочек', 2300),
	('Томбов', 'Завод тумбочек', 2300),
	('Томбов', 'Завод тумбочек', 2300),
	('Томбов', 'Завод тумбочек', 2300),
	('Томбов', 'Завод тумбочек', 2300),
	('Томбов', 'Завод тумбочек', 2300),
	('Томбов', 'Завод тумбочек', 2300),
	('Томбов', 'Завод тумбочек', 2300),
	('Томбов', 'Завод тумбочек', 2300),
	('Томбов', 'Завод тумбочек', 2300),
	('Томбов', 'Завод тумбочек', 2300);

INSERT INTO Windows (name, manufacturer, price)
	VALUES
	('Зеркало души ( окно )', '6 круг', 12300), 
	('Зеркало души ( окно )', '6 круг', 12300),
	('Зеркало души ( окно )', '6 круг', 12300),
	('Зеркало души ( окно )', '6 круг', 12300),
	('Зеркало души ( окно )', '6 круг', 12300),
	('Зеркало души ( окно )', '6 круг', 12300),
	('Зеркало души ( окно )', '6 круг', 12300),
	('Зеркало души ( окно )', '6 круг', 12300),
	('Зеркало души ( окно )', '6 круг', 12300),
	('Зеркало души ( окно )', '6 круг', 12300),
	('Зеркало души ( окно )', '6 круг', 12300), 
	('Зеркало души ( окно )', '6 круг', 12300),
	('Зеркало души ( окно )', '6 круг', 12300),
	('Зеркало души ( окно )', '6 круг', 12300),
	('Зеркало души ( окно )', '6 круг', 12300),
	('Зеркало души ( окно )', '6 круг', 12300),
	('Зеркало души ( окно )', '6 круг', 12300),
	('Зеркало души ( окно )', '6 круг', 12300),
	('Зеркало души ( окно )', '6 круг', 12300),
	('Зеркало души ( окно )', '6 круг', 12300);


INSERT INTO Racks (name, manufacturer, price)
	VALUES
	('Вешело', 'Снасти для всех', 400),
	('Вешело', 'Снасти для всех', 400),
	('Вешело', 'Снасти для всех', 400),
	('Вешело', 'Снасти для всех', 400),
	('Вешело', 'Снасти для всех', 400),
	('Вешело', 'Снасти для всех', 400),
	('Вешело', 'Снасти для всех', 400),
	('Вешело', 'Снасти для всех', 400),
	('Вешело', 'Снасти для всех', 400),
	('Вешело', 'Снасти для всех', 400),
	('Вешело', 'Снасти для всех', 400),
	('Вешело', 'Снасти для всех', 400),
	('Вешело', 'Снасти для всех', 400),
	('Вешело', 'Снасти для всех', 400),
	('Вешело', 'Снасти для всех', 400),
	('Вешело', 'Снасти для всех', 400),
	('Вешело', 'Снасти для всех', 400),
	('Вешело', 'Снасти для всех', 400),
	('Вешело', 'Снасти для всех', 400),
	('Вешело', 'Снасти для всех', 400);

INSERT INTO ShoeRacks (name, manufacturer, price)
	VALUES
	('Подстилка', 'Подстелатий', 3000),
	('Подстилка', 'Подстелатий', 3000),
	('Подстилка', 'Подстелатий', 3000),
	('Подстилка', 'Подстелатий', 3000),
	('Подстилка', 'Подстелатий', 3000),
	('Подстилка', 'Подстелатий', 3000),
	('Подстилка', 'Подстелатий', 3000),
	('Подстилка', 'Подстелатий', 3000),
	('Подстилка', 'Подстелатий', 3000),
	('Подстилка', 'Подстелатий', 3000),
	('Подстилка', 'Подстелатий', 3000),
	('Подстилка', 'Подстелатий', 3000),
	('Подстилка', 'Подстелатий', 3000),
	('Подстилка', 'Подстелатий', 3000),
	('Подстилка', 'Подстелатий', 3000),
	('Подстилка', 'Подстелатий', 3000),
	('Подстилка', 'Подстелатий', 3000),
	('Подстилка', 'Подстелатий', 3000),
	('Подстилка', 'Подстелатий', 3000);

SELECT * FROM Sofas;
SELECT * FROM Chairs;
SELECT * FROM Beds;
SELECT * FROM Wardrobes;
SELECT * FROM Lamps;
SELECT * FROM Desks;
SELECT * FROM Nightstand;
SELECT * FROM Windows;
SELECT * FROM Racks;
SELECT * FROM ShoeRacks;

SELECT * FROM Racks
	WHERE price > 23000
	ORDER BY price;

SELECT * FROM Beds
	WHERE price < 13000
	ORDER BY price DESC;

SELECT * FROM Sofas
	WHERE manufacturer > 'ООО Диванио' AND name = 'Антончик'
	ORDER BY price;

SELECT * FROM Wardrobes
	WHERE price > 23000
	ORDER BY price;

SELECT * FROM Windows
	WHERE price > 23000
	ORDER BY price;

SELECT * FROM ShoeRacks
	WHERE price > 23000 AND price < 30000
	ORDER BY price;

SELECT * FROM Desks
	WHERE name = 'досыка';

SELECT * FROM Chairs
	ORDER BY price, name;

SELECT * FROM Nightstand
	ORDER BY price, name;

SELECT * FROM Lamps
	ORDER BY price DESC, name ASC;

SELECT * FROM Lamps
	WHERE name IN ('лампик', 'лампио') AND price BETWEEN 23400 AND 30000;

SELECT * FROM Nightstand
	WHERE price BETWEEN 1000 AND 3000;

SELECT * FROM Desks
	WHERE manufacturer IN ('ООО Столы', 'ООО Фальшивые Столы');

SELECT * FROM Racks
	WHERE price BETWEEN 5000 AND 10000;

SELECT * FROM ShoeRacks
	WHERE id > 4 AND id BETWEEN 6 AND 8 OR id IN (12, 55);

UPDATE ShoeRacks
	SET name='ногоблуд'
	WHERE name='подставка';

DELETE Lamps
	WHERE id BETWEEN 4 AND 10;

SELECT id, name, SUM(price) AS sum_of_price FROM Sofas
	GROUP BY id, name;

SELECT id, COUNT(*) AS num_of_sofas FROM Sofas
	GROUP BY id;

SELECT id, AVG(price) AS average_price_of_desks FROM Desks
	GROUP BY id;

SELECT id, name, COUNT(*) AS num_of_lamps FROM Lamps
	GROUP BY id, name
	HAVING name='Двухногий';

SELECT id, COUNT(*) AS num_of_chairs FROM Chairs
	GROUP BY id;

SELECT Chairs.id, Chairs.name, Chairs.manufacturer FROM Chairs
	INNER JOIN Sofas
	ON Chairs.id = Sofas.id;

SELECT ShoeRacks.id, ShoeRacks.name FROM ShoeRacks
	LEFT JOIN Racks
	ON ShoeRacks.id = Racks.id;

SELECT ShoeRacks.id, ShoeRacks.name FROM ShoeRacks
	RIGHT JOIN Racks
	ON ShoeRacks.id = Racks.id;

SELECT * FROM Beds
	FULL JOIN Racks 
	ON Beds.id = Racks.id;

SELECT * FROM Beds
	FULL JOIN Racks 
	ON Beds.name = Racks.name;
