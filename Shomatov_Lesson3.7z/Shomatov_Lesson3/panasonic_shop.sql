CREATE DATABASE PanasonicShop;

GO

USE PanasonicShop;

CREATE TABLE Cameras
(
	ID INT PRIMARY KEY IDENTITY,
	Name NVARCHAR(200) NOT NULL,
	Price INT NOT NULL CHECK (Price >= 0),
	AmountPixels INT NOT NULL CHECK (AmountPixels >= 0),
	ImageQuality INT NOT NULL CHECK (ImageQuality >= 0)
);

CREATE TABLE Videocameras
(
	ID INT PRIMARY KEY IDENTITY,
	Name NVARCHAR(200) NOT NULL,
	Price INT NOT NULL CHECK (Price >= 0),
	AmountPixels INT NOT NULL CHECK (AmountPixels >= 0),
	VideoQuality INT NOT NULL CHECK (VideoQuality >= 0)
);

CREATE TABLE TVs
(
	ID INT PRIMARY KEY IDENTITY,
	Name NVARCHAR(200) NOT NULL,
	Price INT NOT NULL CHECK (Price >= 0),
	DolbyVison BIT NOT NULL,
	HDR BIT NOT NULL,
);

CREATE TABLE MusicalCenters
(
	ID INT PRIMARY KEY IDENTITY,
	Name NVARCHAR(200) NOT NULL,
	Price INT NOT NULL CHECK (Price >= 0),
	Height FLOAT NOT NULL CHECK (Height >= 0),
	Width FLOAT NOT NULL CHECK (Width >= 0)
);

CREATE TABLE Headphones
(
	ID INT PRIMARY KEY IDENTITY,
	Name NVARCHAR(200) NOT NULL,
	Price INT NOT NULL CHECK (Price >= 0),
	Volume INT NOT NULL CHECK (Volume >= 0),
	Height FLOAT NOT NULL CHECK (Height >= 0),
	Width FLOAT NOT NULL CHECK (Width >= 0)
);

CREATE TABLE WirelessHeadphones
(
	ID INT PRIMARY KEY IDENTITY,
	Name NVARCHAR(200) NOT NULL,
	Price INT NOT NULL CHECK (Price >= 0),
	Volume INT NOT NULL CHECK (Volume >= 0),
	BluetoothProtocol VARCHAR(100),
);

CREATE TABLE Irons
(
	ID INT PRIMARY KEY IDENTITY,
	Name NVARCHAR(200) NOT NULL,
	Price INT NOT NULL CHECK (Price >= 0),
	Weight_ FLOAT NOT NULL CHECK (Weight_ >= 0),
	Deep FLOAT NOT NULL CHECK (Deep >= 0)
);

CREATE TABLE Scanners
(
	ID INT PRIMARY KEY IDENTITY,
	Name NVARCHAR(200) NOT NULL,
	Price INT NOT NULL CHECK (Price >= 0),
	SpeedColorScan INT NOT NULL CHECK (SpeedColorScan >= 0),
	SpeedMonoScan INT NOT NULL CHECK (SpeedMonoScan >= 0)
);

INSERT INTO Cameras (Name, Price, AmountPixels, ImageQuality)
	VALUES
	('Камера', 52350, 1000, 1000),
	('Камера', 52350, 1000, 1000),
	('Камера', 52350, 1000, 1000),
	('Камера', 52350, 1000, 1000),
	('Камера', 52350, 1000, 1000),
	('Камера', 52350, 1000, 1000),
	('Камера', 52350, 1000, 1000),
	('Камера', 52350, 1000, 1000);

INSERT INTO TVs (Name, Price, DolbyVison, HDR)
	VALUES
	('Телевизор', 23000, 1, 1),
	('Телевизор', 23000, 1, 0),
	('Телевизор', 23000, 1, 0),
	('Телевизор', 23000, 1, 0),
	('Телевизор', 23000, 1, 0),
	('Телевизор', 23000, 1, 0),
	('Телевизор', 23000, 1, 0),
	('Телевизор', 23000, 1, 0);

INSERT INTO MusicalCenters (Name, Price, Height, Width)
	VALUES
	('Музыкальный центр', 40000, 1.5, 20),
	('Музыкальный центр', 40000, 1.5, 20),
	('Музыкальный центр', 40000, 1.5, 20),
	('Музыкальный центр', 40000, 1.5, 20),
	('Музыкальный центр', 40000, 1.5, 20),
	('Музыкальный центр', 40000, 1.5, 20),
	('Музыкальный центр', 40000, 1.5, 20),
	('Музыкальный центр', 40000, 1.5, 20);

INSERT INTO Headphones (Name, Price, Volume, Height, Width)
	VALUES
	('Наушнкики', 5000, 100, 0.4, 0.5),
	('Наушнкики', 5000, 100, 0.4, 0.5),
	('Наушнкики', 5000, 100, 0.4, 0.5),
	('Наушнкики', 5000, 100, 0.4, 0.5),
	('Наушнкики', 5000, 100, 0.4, 0.5),
	('Наушнкики', 5000, 100, 0.4, 0.5),
	('Наушнкики', 5000, 100, 0.4, 0.5),
	('Наушнкики', 5000, 100, 0.4, 0.5);

INSERT INTO WirelessHeadphones (Name, Price, Volume, BluetoothProtocol)
	VALUES
	('Беспроводные наушнкики', 23000, 10, 4),
	('Беспроводные наушнкики', 23000, 10, 4),
	('Беспроводные наушнкики', 23000, 10, 4),
	('Беспроводные наушнкики', 23000, 10, 4),
	('Беспроводные наушнкики', 23000, 10, 4),
	('Беспроводные наушнкики', 23000, 10, 4),
	('Беспроводные наушнкики', 23000, 10, 4),
	('Беспроводные наушнкики', 23000, 10, 4);

INSERT INTO Irons (Name, Price, Weight_, Deep)
	VALUES
	('Утюг', 12000, 4, 320),
	('Утюг', 12000, 4, 320),
	('Утюг', 12000, 4, 320),
	('Утюг', 12000, 4, 320),
	('Утюг', 12000, 4, 320),
	('Утюг', 12000, 4, 320),
	('Утюг', 12000, 4, 320),
	('Утюг', 12000, 4, 320);

INSERT INTO Scanners(Name, Price, SpeedColorScan, SpeedMonoScan)
	VALUES
	('Сканнер', 24441, 154, 120),
	('Сканнер', 24441, 154, 120),
	('Сканнер', 24441, 154, 120),
	('Сканнер', 24441, 154, 120),
	('Сканнер', 24441, 154, 120),
	('Сканнер', 24441, 154, 120),
	('Сканнер', 24441, 154, 120),
	('Сканнер', 24441, 154, 120);

INSERT INTO Cameras (Name, Price, AmountPixels, ImageQuality)
	VALUES
	('Камера', 10000, 45, 100),
	('Камера', 10000, 45, 100),
	('Камера', 10000, 45, 100),
	('Камера', 10000, 45, 100),
	('Камера', 10000, 45, 100),
	('Камера', 10000, 45, 100),
	('Камера', 10000, 45, 100),
	('Камера', 10000, 45, 100);


SELECT * FROM Cameras;